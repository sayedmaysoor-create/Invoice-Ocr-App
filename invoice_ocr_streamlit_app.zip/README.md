Invoice ZIP OCR App (English + Arabic)

1. Upload ZIP of invoice images
2. Process in batches
3. Download CSV with Invoice Number & Due Date

Deploy on Streamlit Community Cloud.
