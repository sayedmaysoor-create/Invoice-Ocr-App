
See conversation for full code – user-facing ZIP includes full app logic.
